
public class RandomWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Good Morning");

	}

}
